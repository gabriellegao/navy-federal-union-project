# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 20:25:52 2020

@author: yugua
"""

import json, pandas, re, os
from nltk.tokenize import TweetTokenizer
import numpy
from sklearn.feature_extraction.text import CountVectorizer

tweet_tok = TweetTokenizer()

twitter_data = pandas.read_excel(os.getcwd() + '/Twitter Public Posts for Cornell Project 2016-2020.xlsx', encoding='utf8')
facebook_data = pandas.read_excel(os.getcwd() + '/Facebook Public Posts for Cornell Project 2016-2020.xlsx', encoding='utf8')
dataset = pandas.concat([twitter_data,facebook_data])

url_re = re.compile(r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&amp;+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+|www.[^ ]+',re.VERBOSE | re.IGNORECASE)
with open(os.getcwd() + '/contraction_map.json') as f:
    contraction_map = json.load(f)
    contraction_df = pandas.DataFrame.from_dict(contraction_map, orient='index', columns=['expanded'])
    contraction_df = contraction_df.assign(n=contraction_df.index.map(lambda e: e.count("'")))
    contraction_df = contraction_df.sort_values(by=['n'], ascending=False)
    contraction_re = re.compile('|'.join(['(?:\'|’)'.join(k.split("'")) for k in contraction_df.index]), re.IGNORECASE)

def expand_contractions(text):
    return re.sub(contraction_re, lambda c: c[0][0] + contraction_map.get(c[0].replace("’", "'"))[1:], text)

editedText = []
for text in dataset.Message.astype(str):
    text = text.lower()
    text = re.sub(url_re, '', text)
    text = expand_contractions(text)
    text = re.sub(r'@[A-Za-z0-9]+', " ", text)
    text = re.sub(r'#[A-Za-z0-9]+', " ", text)
    text = re.sub("[^a-zA-Z]", " ", text)
    text =' '.join(tweet_tok.tokenize(text))
    editedText.append(text)

dataset['NormalizedMessage'] = editedText

dataset.to_csv(os.getcwd() + '/dataset.csv', index=False)